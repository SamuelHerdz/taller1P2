/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enums;

/**
 *
 * @author DELL
 */
public enum EstadoCita {
    PENDIENTE, CONFIRMADA, EN_ATENCION, COMPLETADA, CANCELADA
            }

