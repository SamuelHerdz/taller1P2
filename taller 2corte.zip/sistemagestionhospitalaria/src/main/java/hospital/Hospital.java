/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospital;
import abstractas.Empleado;
import personas.Paciente;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author DELL
 */
public class Hospital {
    private String nombre;
    private List<Empleado> empleados;
    private List<Paciente> pacientes;
    
    public Hospital(String nombre){
        this.nombre = nombre;
        this.empleados = new ArrayList<>();
        this.pacientes = new ArrayList<>();
    }
    
    public void contratarEmpleado(Empleado e){
        empleados.add(e);
    }
    
    public double calcularNominaTotal(){
        double total = 0;
        for (Empleado e : empleados){
            total += e.calcularSalario();
        }
        return total;
        
    }
    
}
