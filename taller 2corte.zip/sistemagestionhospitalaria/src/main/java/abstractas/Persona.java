/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractas;

import java.time.LocalDate;

/**
 *
 * @author DELL
 */
public abstract class Persona {

    private int id;
    private String nombre;
    private String apellido;
    private LocalDate fechaNacimiento;
    private String email;

    public Persona(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
    }
public abstract int calcularEdad();
public abstract String obtenerTipo();

      public LocalDate getFechaNacimiento(){
          return fechaNacimiento;
      }
    
}
