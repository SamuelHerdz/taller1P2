/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personas;
import hospital.Especialidad;
import java.time.LocalDate;
/**
 *
 * @author DELL
 */
public class Cirujano extends Medico {

    private int cirugiasRealizadas;

    public Cirujano(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                    String legajo, LocalDate fechaContratacion, double salarioBase,
                    String numeroLicencia, Especialidad especialidad) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase, numeroLicencia, especialidad);
    }

    public double calcularBono() {
        return cirugiasRealizadas * 50;
    }

    @Override
    public double calcularSalario() {
        return super.calcularSalario() + calcularBono();
    }

    @Override
    public String obtenerTipo() {
        return "Cirujano";
    
    }
}

