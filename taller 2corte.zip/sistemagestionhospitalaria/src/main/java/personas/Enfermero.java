/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personas;
import abstractas.Empleado;
import enums.Turno;
import java.time.LocalDate;

/**
 *
 * @author DELL
 */
public class Enfermero extends Empleado {

    private Turno turno;

    public Enfermero(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                     String legajo, LocalDate fechaContratacion, double salarioBase, Turno turno) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        this.turno = turno;
    }

    @Override
    public double calcularSalario() {
        return 800 + (turno == Turno.NOCHE ? 200 : 0);
    }

    @Override
    public String obtenerTipo() {
        return "Enfermero";
    }
}