/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personas;
import abstractas.Empleado;
import hospital.Especialidad;
import java.time.LocalDate;
/**
 *
 * @author DELL
 */

public class Medico extends Empleado {

    private String numeroLicencia;
    private Especialidad especialidad;

    public Medico(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                  String legajo, LocalDate fechaContratacion, double salarioBase,
                  String numeroLicencia, Especialidad especialidad) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        this.numeroLicencia = numeroLicencia;
        this.especialidad = especialidad;
    }

    @Override
    public double calcularSalario() {
        return 1000 + (antiguedad() * 100);
    }

    @Override
    public String obtenerTipo() {
        return "Medico";
    }
}
