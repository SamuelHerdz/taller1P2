/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personas;
import abstractas.Persona;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author DELL
 */
public class Paciente extends Persona{
    private String historiaClinicaId;
    private String grupoSanguineo;
    private List<String> alergias;
    private List<String> citas;
    
    public Paciente(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                    String historiaClinicaId, String grupoSanguineo){
        super(id, nombre, apellido, fechaNacimiento, email);
        this.historiaClinicaId = historiaClinicaId;
    this.grupoSanguineo = grupoSanguineo;
    this.alergias = new ArrayList<>();
    this.citas = new ArrayList<>();
    }
    
    public void agregarAlergia(String alergia){
        alergias.add(alergia);
    }
    
    @Override
    public int calcularEdad(){
        return java.time.Period.between(getFechaNacimiento(), LocalDate.now()).getYears();
    }
    
    @Override
    public String obtenerTipo(){
        return "Paciente";
    }
    
            
}
