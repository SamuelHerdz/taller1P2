/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemagestionhospitalaria;
import abstractas.Empleado;
import enums.Turno;
import hospital.Especialidad;
import personas.*;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author DELL
 */
public class Sistemagestionhospitalaria {

     public static void main(String[] args) {

        Especialidad esp = new Especialidad("001", "General", "Medicina General", 50);

        Medico m = new Medico(1, "Juan", "Perez", LocalDate.of(1980,1,1), "a@mail.com",
                "L1", LocalDate.of(2010,1,1), 1000, "LIC123", esp);

        Cirujano c = new Cirujano(2, "Ana", "Gomez", LocalDate.of(1985,2,2), "b@mail.com",
                "L2", LocalDate.of(2015,1,1), 1200, "LIC456", esp);

        Enfermero e = new Enfermero(3, "Luis", "Lopez", LocalDate.of(1990,3,3), "c@mail.com",
                "L3", LocalDate.of(2020,1,1), 800, Turno.NOCHE);

        List<Empleado> lista = new ArrayList<>();
        lista.add(m);
        lista.add(c);
        lista.add(e);

        
        for (Empleado emp : lista) {
            System.out.println(emp.obtenerTipo() + " salario: " + emp.calcularSalario());
        }
    }
}